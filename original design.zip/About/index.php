<?php //Auto-generated content. Changes made may be lost at any time. //Modify using GUI or modify content.php and run build. ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/head-include.php'; ?>
</head>
<body>
<div id="header">
    <div id="nav">
        <div class="row">
            <div class="column">
                <div id="logo">
                    <a href="#">Code Orange</a>
                </div>
                <div id="user">
                    <a href="#">Login</a>
                </div>
                <div id="nav-menu">
                    <div class="scroll-hide">
                        <div class="scroll-fix">
                            <?php include $_SERVER['DOCUMENT_ROOT'].'/menu.php'; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="selection-bar" class="selection-nav">

    </div>
</div>
<div id="header-filler">
    <div id="nav-filler">
        <div class="row">
            <div class="column">
                <div id="logo-filler">
                    <a href="#">Code Orange</a>
                </div>
                <div id="user-filler">
                    <a href="#">Login</a>
                </div>
                <div id="nav-menu-filler">
                    <div class="scroll-hide">
                        <div class="scroll-fix">
                            <?php include $_SERVER['DOCUMENT_ROOT'].'/menu.php'; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="selection-bar-filler" class="selection-nav">

    </div>
</div>
<div id="selection-bar-outside" class="selection-content">
    <?php include 'content.htm'; ?>
</div>
<div id="body">

</div>
<div id="footer"></div>
<?php include $_SERVER['DOCUMENT_ROOT'].'/js-include.php'; ?>
</body>
</html>