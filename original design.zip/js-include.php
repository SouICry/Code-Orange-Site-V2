<?php

include $_SERVER['DOCUMENT_ROOT'].'/js-include.htm';

?>