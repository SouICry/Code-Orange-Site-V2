# Code-Orange-Site-V2
Refresh for FRC Team Code Orange Website

With the project reaching a relatively stable state, the contents in this repository are currently deployed to v2.teamcodeorange.com for preview purposes.

Bugs are still to be expected, as is additional content (like a home page). Nothing breaking though (at least I hope).