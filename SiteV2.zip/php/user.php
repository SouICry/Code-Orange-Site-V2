<a  class="edit-button manage-none">Edit</a>
<div class="preview-button manage-button">Preview</div>
<div class="save-button manage-button">Save</div>
<div class="publish-button manage-button">Publish</div>
<a href="#">Login</a>
