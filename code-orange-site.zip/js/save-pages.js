/**
 * Created by SouICry on 11/3/2015.
 */

//TODO

function savePages(){
    var pages = $('#selection-bar-filler .scroll-fix a').not('.manage-button').not('.slider-filler');
}