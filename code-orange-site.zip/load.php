<?php
  include $_GET['url'];
?>