<?php
;
echo ($_POST);

?>