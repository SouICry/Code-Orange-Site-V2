<?php //Auto-generated content. Changes made may be lost at any time.  ?>
<script>
    window.location.href = '';
</script>