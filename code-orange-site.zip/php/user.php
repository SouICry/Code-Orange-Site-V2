<div class="edit-button manage-none">Edit</div>
<div class="preview-button manage-button">Preview</div>
<div class="save-button manage-button">Save</div>
<div class="publish-button manage-button">Publish</div>
<a href="#">Login</a>
